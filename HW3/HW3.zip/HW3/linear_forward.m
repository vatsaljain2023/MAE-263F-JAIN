%% Vatsal Jain
% 605343009

function Z = linear_forward(A_prev, W, b)
    Z = W * A_prev + b;
end